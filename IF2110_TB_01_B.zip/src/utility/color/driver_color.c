#include <stdio.h>
#include "color.h"

// int main () {
//     char c = 'A';
//     char str[] = "Test 123";

//     printRed(c);
//     printGreen(c);
//     printYellow(c);
//     printBlue(c);
//     printMagenta(c);
//     printCyan(c);

//     printf("\n");

//     sprintRed(str);
//     sprintGreen(str);
//     sprintYellow(str);
//     sprintBlue(str);
//     sprintMagenta(str);
//     sprintCyan(str);

//     return 0;
// }