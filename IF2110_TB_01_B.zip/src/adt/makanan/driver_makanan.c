// #include <stdio.h>
// #include "makanan.h"
// #include "../time/time.h"

// int main() {
//     Makanan M;
//     TIME EXP;
//     TIME DLVRY;
//     TIME PENGOLAHAN;
//     POINT P;
    
//     CreateTime(&EXP, 1, 2, 3);
//     CreateTime(&DLVRY, 1, 10, 3);
//     CreateTime(&DLVRY, 1, 10, 3);
//     CreateTime(&PENGOLAHAN, 1, 10, 3);

//     CreatePoint(&P, 1, 1);

//     createMakanan(&M, 123, "ayam", EXP, 'T', DLVRY, P, PENGOLAHAN);

//     return 0;
// }