// #include <stdio.h>
// #include "map.h"

// int main()  {
//     Map tmpmap;
//     POINT sim;
//     CreateMap(&tmpmap, 10, 10);
//     DisplayMap(tmpmap, sim);
// }