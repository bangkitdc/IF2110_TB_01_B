// #include "time.h"
// #include <stdio.h>

// int main(){
//     TIME time;

//     CreateTime(&time, 1,2,3);
//     TulisTIME(time);
//     printf("\n");
//     TulisTIME2(time);
//     printf("\n");
//     TulisTIME3(time);
//     printf("\n");
//     TulisTIME4(time);
//     printf("\n");
//     TulisTIME5(time);
//     printf("\n");

//     printf("%d", TIMEToMenit(time));

//     return 0;
// }