// #include <stdio.h>
// #include "point.h"

// int main() {
//     POINT tmp1;
//     POINT tmp2;
//     POINT tmp3;

//     ReadPoint(&tmp1);
//     ReadPoint(&tmp2);
//     CreatePoint(&tmp3,7 , 9);

//     WritePoint(tmp1); printf("\n");
//     WritePoint(tmp2); printf("\n");
//     MoveE(tmp1);
//     MoveN(tmp2);
//     WritePoint(tmp1); printf("\n");
//     WritePoint(tmp2); printf("\n");
//     MoveW(tmp1);
//     MoveS(tmp2);
//     WritePoint(tmp1); printf("\n");
//     WritePoint(tmp2); printf("\n");

//     boolean cek = SideBy(tmp1, tmp2);
//     printf("%d", cek);
// }