// #include <stdio.h>
// #include "wordmachine.h"

// /* Driver input Console */

// int main() {
//     ListWord L;
//     createListWord(&L);

//     L = readLine();

//     int p = wordToInt(L.TabWords[0]);
//     printf("%d\n", p);

//     return 0;
// }