// #include "stack.h"
// #include <stdio.h>

// int main() {
//     Stack S1;

//     CreateEmptyStack(&S1);

//     // if (IsStackEmpty(S1)) {
//     //     printf("Empty\n");
//     // } else {
//     //     printf("Not Empty\n");
//     // }

//     printf("test\n");
//     return 0;
// }