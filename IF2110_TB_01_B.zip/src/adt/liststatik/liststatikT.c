#include "stdio.h"
#include "liststatikT.h"

void CreateListTree(ListStatikT *lt){
    (*lt).elEff = 0;
    for(int i=0;i<MAX_RESEP;i++){
        (*lt).list[i] = NULL;
    }
}