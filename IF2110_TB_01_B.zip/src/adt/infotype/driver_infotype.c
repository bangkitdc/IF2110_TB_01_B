// #include <stdio.h>
// #include "infotype.h"
// #include "../point/point.h"

// int main() {
//     infotype temp, dummy;
//     Makanan tempmakanan;
//     TIME temptime;
//     POINT templokasi;

//     CreatePoint(&templokasi, 1, 1);
//     CreateTime(&temptime, 1, 3, 2);
//     createMakanan(&tempmakanan, 12, "ayam", temptime, 'R', temptime, templokasi, temptime);

//     MakeinfoType(&temp, tempmakanan);
//     makeDummyInfoType(&dummy);

//     return 0;
// }